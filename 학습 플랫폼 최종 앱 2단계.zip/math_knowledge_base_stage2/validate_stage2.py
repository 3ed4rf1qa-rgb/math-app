import json, re, sys
from pathlib import Path
BASE=Path(__file__).resolve().parent

def load(name):
    with (BASE/name).open(encoding='utf-8') as f: return json.load(f)

def main():
    data=load('achievement_standards.json')
    rows=data['standards']
    catalog=load('curriculum_catalog.json')
    valid_courses={c['id']:c for c in catalog['courses']}
    valid_units={(c['id'],u['id'],u['title']) for c in catalog['courses'] for u in c['units']}
    assert len(rows)==130, f'expected 130, got {len(rows)}'
    codes=[r['code'] for r in rows]
    assert len(codes)==len(set(codes)), 'duplicate code'
    assert all(r['course_id'] and r['unit_id'] and r['content'] for r in rows)
    expected={'공통수학1':19,'공통수학2':20,'대수':18,'미적분Ⅰ':20,'확률과 통계':16,'미적분Ⅱ':23,'기하':14}
    from collections import Counter
    counts=Counter(r['course_name'] for r in rows)
    assert dict(counts)==expected, dict(counts)
    assert all(re.match(r'^(10공수[12]-\d{2}-\d{2}|12(대수|확통|기하)\d{2}-\d{2}|12미적[ⅠⅡ]-\d{2}-\d{2})$',r['code']) for r in rows)
    guidance=load('area_guidance.json')['areas']
    assert len(guidance)==22
    gkeys={(g['course_id'],g['unit_id']) for g in guidance}
    assert len(gkeys)==22
    cross=load('legacy_105_audit.json')
    assert cross['metadata']['legacy_row_count']==105
    assert len(cross['records'])==105
    # Every official standard code must be traceable to a PDF page and source ref.
    for r in rows:
        s=r['source']
        assert s.get('printed_pages') and s.get('pdf_text_lines') and s.get('web_source_ref')
        assert r['course_id'] in valid_courses, f"unknown course: {r['course_id']}"
        assert (r['course_id'],r['unit_id'],r['unit_name']) in valid_units, f"unknown unit: {r['unit_name']}"
    try:
        import jsonschema
        schema=load('achievement_standard_schema.json')
        jsonschema.validate(data,schema)
        schema_result='JSON Schema PASS'
    except ImportError:
        schema_result='JSON Schema SKIPPED (install jsonschema to run the schema check)'
    print('PASS: 130 standards; 7 courses; 22 areas; unique IDs/codes; source pointers and catalog links present; 105 legacy rows retained; '+schema_result)
    print('COURSE COUNTS:',dict(counts))
    print('LEGACY COMPARISON:',cross['core_course_comparison']['legacy_match_status_counts'])
if __name__=='__main__': main()
