from pathlib import Path
import json, sys
from collections import Counter
try:
    import jsonschema
except ImportError:
    jsonschema = None
ROOT=Path(__file__).resolve().parent
load=lambda p: json.loads(p.read_text(encoding='utf-8'))
std=load(ROOT/'curriculum'/'achievement_standards.json')['standards']
concepts=load(ROOT/'all_concepts.json')['concepts']
mis=load(ROOT/'all_misconceptions.json')['misconceptions']
acts=load(ROOT/'all_inquiry_activities.json')['activities']
items=load(ROOT/'all_item_blueprints.json')['item_blueprints']
maps=load(ROOT/'all_standard_concept_map.json')['mappings']
ids=lambda xs,key='id':[x[key] for x in xs]
assert len(ids(concepts))==len(set(ids(concepts))), 'duplicate concept id'
assert len(ids(mis))==len(set(ids(mis))), 'duplicate misconception id'
assert len(ids(acts))==len(set(ids(acts))), 'duplicate activity id'
assert len(ids(items))==len(set(ids(items))), 'duplicate item id'
std_codes={x['code'] for x in std}; concept_ids=set(ids(concepts)); mis_ids=set(ids(mis)); act_ids=set(ids(acts)); item_ids=set(ids(items))
assert len(std_codes)==130, f'expected 130 official standards, got {len(std_codes)}'
map_codes={x['standard_code'] for x in maps}
assert std_codes <= map_codes, f'unmapped standards: {sorted(std_codes-map_codes)}'
assert len(concepts)==130, f'expected 130 concepts, got {len(concepts)}'
assert len(mis)==142, f'expected 142 misconceptions, got {len(mis)}'
assert len(acts)==130, f'expected 130 activities, got {len(acts)}'
assert len(items)==130, f'expected 130 blueprints, got {len(items)}'
expected_course_counts={'HS-COMMON-MATH-1':17,'HS-COMMON-MATH-2':18,'HS-ALGEBRA':15,'HS-PROB-STAT':13,'HS-CALCULUS-1':30,'HS-CALCULUS-2':23,'HS-GEOMETRY':14}
from collections import Counter
assert Counter(c['course_id'] for c in concepts)==Counter(expected_course_counts), 'course concept count mismatch'
for cid,expected in expected_course_counts.items():
    course_dir=ROOT/'courses'/cid
    assert course_dir.is_dir(), f'missing course directory {cid}'
    course_concepts=load(course_dir/'concepts.json')['concepts']
    assert len(course_concepts)==expected, f'course bundle count mismatch {cid}'
    assert len(load(course_dir/'official_standards.json')['standards'])==len([s for s in std if s['course_id']==cid])
standard_by_code={s['code']:s for s in std}
for m in maps:
    source=standard_by_code[m['standard_code']]
    assert all(next(c for c in concepts if c['id']==concept_id)['course_id']==source['course_id'] for concept_id in m['concept_ids']), f'cross-course mapping {m["standard_code"]}'
relations=load(ROOT/'concept_relations.json')['relations']
assert all(r['from_concept_id'] in concept_ids and r['to_concept_id'] in concept_ids for r in relations), 'broken concept relation'
# Check that directed learning-sequence suggestions do not form cycles.
graph={c['id']:[] for c in concepts}
for r in relations: graph[r['from_concept_id']].append(r['to_concept_id'])
state={}
def visit(node):
    state[node]=1
    for nxt in graph[node]:
        if state.get(nxt)==1: raise AssertionError(f'cycle in concept relations at {nxt}')
        if state.get(nxt,0)==0: visit(nxt)
    state[node]=2
for node in graph:
    if state.get(node,0)==0: visit(node)
assert len(relations)==142, f'expected 142 relation proposals, got {len(relations)}'
for c in concepts:
    assert c['course_id'] and c['unit_id'] and c['definition']
    assert set(c.get('standard_codes',[])) <= std_codes, f"unknown standard in {c['id']}"
    assert set(c.get('misconception_ids',[])) <= mis_ids, f"broken misconception ref {c['id']}"
    assert set(c.get('inquiry_activity_ids',[])) <= act_ids, f"broken activity ref {c['id']}"
    assert set(c.get('item_blueprint_ids',[])) <= item_ids, f"broken blueprint ref {c['id']}"
for m in maps:
    assert set(m['concept_ids']) <= concept_ids, f"broken map {m['standard_code']}"
for i in items:
    assert i.get('design_prompt') or i.get('prompt_design'), f"empty blueprint {i['id']}"
# Validate the new-course concept records against JSON Schema.
schema=load(ROOT/'concept_schema.json')
if jsonschema:
    new_course_ids={'HS-COMMON-MATH-1','HS-COMMON-MATH-2','HS-ALGEBRA','HS-PROB-STAT','HS-CALCULUS-2','HS-GEOMETRY'}
    for c in concepts:
        if c['course_id'] in new_course_ids:
            jsonschema.validate(c,schema)
# Parse all JSON files to catch malformed course-level data too.
for p in ROOT.rglob('*.json'): load(p)
print('PASS')
print(f'Official standards mapped: {len(std_codes)}')
print(f'Concepts: {len(concepts)} | Misconceptions: {len(mis)} | Inquiry activities: {len(acts)} | Item blueprints: {len(items)}')
print('Unique IDs, cross references, standard coverage, schemas and JSON files: PASS')
print('Teacher expert review: PENDING')
