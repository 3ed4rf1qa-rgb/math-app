import json
from pathlib import Path
from jsonschema import Draft202012Validator

root = Path(__file__).parent
catalog = json.loads((root / "curriculum_catalog.json").read_text(encoding="utf-8"))
schema = json.loads((root / "knowledge_schema.json").read_text(encoding="utf-8"))
sample = json.loads((root / "sample_inquiry_authored.json").read_text(encoding="utf-8"))
Draft202012Validator.check_schema(schema)
validator = Draft202012Validator(schema)
errors = sorted(validator.iter_errors(sample), key=lambda e: list(e.path))
assert not errors, "sample record schema validation failed: " + "; ".join(e.message for e in errors)
course_ids = [c["id"] for c in catalog["courses"]]
assert len(course_ids) == len(set(course_ids)), "duplicate course id"
unit_ids = [u["id"] for c in catalog["courses"] for u in c["units"]]
assert len(unit_ids) == len(set(unit_ids)), "duplicate unit id"
assert len(catalog["courses"]) == 7, "expected 7 core courses"
assert sum(len(c["units"]) for c in catalog["courses"]) == 22, "expected 22 units"
assert all(len(c["units"]) > 0 for c in catalog["courses"])
print(f"PASS: {len(course_ids)} core courses, {len(unit_ids)} units, schema and sample record valid")
