import json
import unittest
from pathlib import Path
from engine import create_store, generate_package, generate_with_client, validate_package_against_store, GenerationError

ROOT = Path(__file__).resolve().parents[1]

class FakeResponse:
    def __init__(self, payload):
        self.text = json.dumps(payload, ensure_ascii=False)

class FakeModels:
    def __init__(self, payload):
        self.payload = payload
        self.calls = []
    def generate_content(self, **kwargs):
        self.calls.append(kwargs)
        return FakeResponse(self.payload)

class FakeClient:
    def __init__(self, payload):
        self.models = FakeModels(payload)

class EngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.store = create_store(ROOT / "data")

    def test_offline_pipeline_all_courses(self):
        courses = self.store.list_courses()
        self.assertEqual(len(courses), 7)
        total = 0
        for course in courses:
            standards = self.store.list_standards(course["course_id"])
            self.assertTrue(standards)
            total += len(standards)
            package = generate_package(self.store, course["course_id"], standards[0]["code"], mode="offline")
            self.assertEqual(package["validation"]["status"], "SCAFFOLD_ONLY")
            self.assertEqual(package["selection"]["standard_code"], standards[0]["code"])
        self.assertEqual(total, 130)

    def test_wrong_course_code_rejected(self):
        with self.assertRaises(ValueError):
            self.store.build_context("HS-COMMON-MATH-1", "12미적Ⅰ-02-05")

    def test_unknown_code_rejected(self):
        with self.assertRaises(KeyError):
            self.store.build_context("HS-CALCULUS-1", "NOT-A-STANDARD")

    def test_gemini_structured_adapter_mock(self):
        context = self.store.build_context("HS-CALCULUS-1", "12미적Ⅰ-02-05")
        offline = generate_package(self.store, "HS-CALCULUS-1", "12미적Ⅰ-02-05", mode="offline")
        payload = {k: offline[k] for k in ["design", "item", "formative_check"]}
        payload["design"]["context"] = "함수 그래프 위 한 점에서 접선 기울기를 구하는 상황."
        payload["design"]["driving_question"] = "한 점에서 접선의 기울기를 어떻게 구할 수 있을까?"
        payload["item"]["prompt"] = "f(x)=x^3-3x^2+2에서 x=1일 때 접선의 방정식을 구하고, 미분계수와 접선 기울기의 관계를 설명하시오."
        payload["item"]["expected_answer"] = "y=-3x+3"
        payload["item"]["solution_steps"] = ["f'(x)=3x²-6x", "f(1)=0, f'(1)=-3", "y=-3(x-1)=-3x+3"]
        payload["item"]["rubric"]["criteria"] = [
            {"criterion":"도함수 계산","points":3,"levels":{x:f"{x} 수준의 도함수 계산 증거" for x in "ABCDE"}},
            {"criterion":"접점·기울기 해석","points":3,"levels":{x:f"{x} 수준의 접점·기울기 해석 증거" for x in "ABCDE"}},
            {"criterion":"접선 방정식","points":2,"levels":{x:f"{x} 수준의 접선 방정식 구성 증거" for x in "ABCDE"}},
            {"criterion":"논리적 설명","points":2,"levels":{x:f"{x} 수준의 논리적 설명 증거" for x in "ABCDE"}}
        ]
        payload["item"]["rubric"]["total_points"] = 10
        client = FakeClient(payload)
        generated = generate_with_client(context, client, model="fake-model", max_attempts=1)
        self.assertEqual(generated["item"]["expected_answer"], "y=-3x+3")
        self.assertEqual(client.models.calls[0]["config"]["response_mime_type"], "application/json")
        self.assertIn("response_json_schema", client.models.calls[0]["config"])

    def test_context_contains_scope_and_concepts(self):
        ctx = self.store.build_context("HS-CALCULUS-1", "12미적Ⅰ-02-05")
        self.assertTrue(ctx["concepts"])
        self.assertTrue(ctx["guardrails"].get("allowed_core"))
        self.assertTrue(ctx["activities"])
        self.assertTrue(ctx["misconceptions"])

if __name__ == "__main__":
    unittest.main()
