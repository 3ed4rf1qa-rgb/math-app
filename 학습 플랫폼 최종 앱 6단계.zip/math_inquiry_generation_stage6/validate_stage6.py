from pathlib import Path
import json
from engine import create_store, generate_package, validate_package_against_store

ROOT = Path(__file__).resolve().parent
store = create_store(ROOT / "data")
courses = store.list_courses()
assert len(courses) == 7
standard_total = 0
for course in courses:
    standards = store.list_standards(course["course_id"])
    standard_total += len(standards)
    assert standards
    package = generate_package(store, course["course_id"], standards[0]["code"], mode="offline")
    assert package["validation"]["status"] == "SCAFFOLD_ONLY"
assert standard_total == 130
sample = json.loads((ROOT / "data" / "sample_generated_package.json").read_text(encoding="utf-8"))
result = validate_package_against_store(store, sample)
assert not result["blocking_errors"], result
assert result["status"] == "PASS_WITH_TEACHER_REVIEW"
print("PASS")
print(f"Courses: {len(courses)} | Official standards: {standard_total}")
print("Offline scaffold flow: 7/7 courses")
print("Sample end-to-end item, answer, solution and rubric: PASS")
print("Course/standard binding, cross references, JSON Schema: PASS")
