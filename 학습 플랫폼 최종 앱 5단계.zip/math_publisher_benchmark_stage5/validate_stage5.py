from pathlib import Path
import json, csv
ROOT = Path(__file__).resolve().parent
def load(n): return json.loads((ROOT/n).read_text(encoding='utf-8'))
b=load('publisher_benchmark.json'); p=load('design_principles.json')['principles']
l=load('lesson_blueprint_calculus1_derivative.json'); a=load('assessment_architecture.json')
s={x['id'] for x in b['sources']}
assert len(b['publishers'])==6 and len(s)==13 and len(p)==12
assert all(set(x['sources'])<=s for x in b['publishers'])
assert all(set(x['evidence_sources'])<=s for x in p)
assert sum(int(x['minutes'].split('-')[1])-int(x['minutes'].split('-')[0]) for x in l['lesson_flow'])==50
assert sum(x['points'] for x in l['original_assessment']['rubric'])==10
assert len(a['types'])==6
with (ROOT/'publisher_comparison_matrix.csv').open(encoding='utf-8-sig') as f: assert len(list(csv.reader(f)))==7
print('PASS')
print('Publishers: 6 | Source records: 13 | Design principles: 12')
print('Lesson blueprint: 50 minutes | Rubric: 10/10')
print('JSON parsing, cross references, CSV structure: PASS')
