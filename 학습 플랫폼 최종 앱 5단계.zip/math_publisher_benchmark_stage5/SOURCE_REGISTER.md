# 공개 출처 목록 — 확인일 2026-11-10

| 출판사 | 자료 | URL | 확인한 범위 |
|---|---|---|---|
| 미래엔 | 엠티처 서비스 안내 | https://g.m-teacher.co.kr/pages/common/customer/useinfo.mrn | 수업·평가·멀티미디어·AI클래스 리포트 |
| 미래엔 | 엠티처 FAQ | https://h.m-teacher.co.kr/pages/common/customer/faq.mrn | 교사용 자료 접근 자격 및 저작권 |
| 비상교육 | 비바샘 문제은행 | https://v.vivasam.com/qbank/qbank_subject.do | 2022 개정 수학 과목별 문항은행 목록 |
| 비상교육 | 고등 대수 자료실 | https://v.vivasam.com/educourse/index.do?textbookCd=106465 | 스마트 교과서, 지도서, 수업·평가 자료 |
| 천재교과서 | T셀파 소개 | https://m.chunjaetext.co.kr/shopinfo/business/tsherpa.html | 교사 대상 수업·평가 지원 플랫폼 |
| 천재교과서 | 공통수학1 샘플 차례 | https://cdata2.tsherpa.co.kr/ebook/tsherpa/22/22ebook_H/EB2022GC3MM_01_10J_S/resource/include/main/index.html | 개념 탐구·디지털 도구·실생활·프로젝트·평가 |
| 동아출판 | 두클래스 서비스 | https://company.dong-a.com/service.donga | 교과서 맞춤 콘텐츠·교과연계 자료 |
| 동아출판 | 고등 학습자료 | https://www.bookdonga.com/high/extradata_list.donga | 평가자료·정답해설·요점정리·보충자료 유형 |
| 씨마스 | 수학과 문화 | https://teachingsaem.cmass.kr/textbook-material/detail/732 | 예술·생활·사회·환경 주제 및 자료 유형 |
| 씨마스 | 경제 수학 | https://teachingsaem.cmass.kr/textbook-material/detail/533 | 금융·경제·함수·행렬·미분 적용 맥락 |
| YBM | 고등 교과서 목록 | https://www.ybmcloud.com/prcenter/ybmtextbook?siteType=H | 2022 개정 수학 과목 및 수업자료 유형 |
| YBM | 대수 선정 사유서 | https://www.ybmcloud.com/prcenter_contents/C202408191133483ZSRj/download | 공학 도구·탐구·다면평가 |
| YBM | 미적분Ⅰ 선정 사유서 | https://www.ybmcloud.com/prcenter_contents/C20240819114434Yut4V/download | 모듈형 설명·비주얼 개념·AI 질문·자기평가 |

동아출판은 공개 자료에서 플랫폼 기능은 확인했지만 2022 개정 고등 수학 교과서 본문 교수법은 직접 확인하지 못했다. YBM PDF의 화면 스크린샷은 웹 도구의 리디렉션 오류로 확인하지 못하고 텍스트 추출을 사용했다.
